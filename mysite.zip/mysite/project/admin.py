from django.contrib import admin

from .models import *

# Register your models here.
admin.site.register(staff)
admin.site.register(realtime)
admin.site.register(project)
admin.site.register(projectasset)
admin.site.register(projectres)
